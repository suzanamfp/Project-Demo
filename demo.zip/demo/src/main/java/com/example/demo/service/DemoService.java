package com.example.demo.service;

import java.util.List;

import javax.persistence.Table;

import org.springframework.stereotype.Service;

import com.example.demo.model.Demo;
import com.example.demo.repository.DemoRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
//@Table(name = "Demo")
public class DemoService {

	private final DemoRepository repository;
	
	public void save(Demo demo) {
		this.repository.save(demo);
	}

	
	public List<Demo> demos(){
		return this.repository.findAll();
	}
	
	public void remove(Long id){
		this.repository.deleteById(id);
	}


	public Demo getByName(String name) {
		return this.repository.findByName(name);
		
	}


	public Demo getByEmail(String email) {
		return this.repository.findByEmail(email);
	}


	public Demo getByTelefone(String telefone) {
		return this.repository.findByTelefone(telefone);
	}
	
}
