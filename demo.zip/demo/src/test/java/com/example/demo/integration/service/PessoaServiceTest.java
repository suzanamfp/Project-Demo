package com.example.demo.integration.service;



import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.demo.model.Demo;
import com.example.demo.repository.DemoRepository;
import com.example.demo.service.DemoService;

@SpringBootTest
public class PessoaServiceTest {
	
	@Autowired
	private DemoService demoService;
	
	@MockBean
	private DemoRepository repository;
	
	@Test
	public void retornaPessoaPorEmail() {
		var pessoa = Demo.builder().name("Carlos").email("carlos@gmail.com").telefone("5555").build();
		
		Mockito.when(repository.findByEmail(pessoa.getEmail())).thenReturn(pessoa);
		
		Assertions.assertEquals(demoService.getByEmail("carlos@gmail.com").getName(), "Carlos");
		
	}
	
	

}
